package com.umko.studentplanner;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView txtGreeting, txtSemester;
    TextView txtEmptySchedule, txtToday;
    TextView txtScheduleCount, txtSemesterCount;

    Button btnSchedule;
    ImageButton btnSettings;

    LinearLayout layoutScheduleHome;

    PrefsManager prefsManager;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefsManager = new PrefsManager(this);
        databaseHelper = new DatabaseHelper(this);

        txtGreeting = findViewById(R.id.txtGreeting);
        txtSemester = findViewById(R.id.txtSemester);

        txtToday = findViewById(R.id.txtToday);
        txtEmptySchedule = findViewById(R.id.txtEmptySchedule);

        txtScheduleCount = findViewById(R.id.txtScheduleCount);
        txtSemesterCount = findViewById(R.id.txtSemesterCount);

        btnSchedule = findViewById(R.id.btnSchedule);
        btnSettings = findViewById(R.id.btnSettings);

        layoutScheduleHome = findViewById(R.id.layoutScheduleHome);

        btnSchedule.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    ScheduleActivity.class
            );
            startActivity(intent);
        });

        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    SettingsActivity.class
            );
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (prefsManager != null) {
            String name = prefsManager.getName();
            String semester = prefsManager.getSemester();

            txtGreeting.setText("Halo, " + name + "!");
            txtSemester.setText("Semester " + semester);
            txtSemesterCount.setText(semester);
        }

        loadScheduleHome();
    }

    private void loadScheduleHome() {

        layoutScheduleHome.removeAllViews();

        // Mengambil hari dan tanggal sekarang
        Locale indonesia = new Locale("id", "ID");

        SimpleDateFormat dayFormat =
                new SimpleDateFormat("EEEE", indonesia);

        SimpleDateFormat dateFormat =
                new SimpleDateFormat("EEEE, dd MMMM yyyy", indonesia);

        String today = dayFormat.format(new Date());
        String todayDate = dateFormat.format(new Date());

        today = capitalize(today);

        // Tampilkan tanggal di beranda
        txtToday.setText(todayDate);

        Cursor cursor = databaseHelper.getAllSchedules();

        int totalToday = 0;

        if (cursor == null) {
            txtScheduleCount.setText("0");
            txtEmptySchedule.setVisibility(View.VISIBLE);
            txtEmptySchedule.setText(
                    "Tidak dapat mengambil data jadwal."
            );
            return;
        }

        try {

            while (cursor.moveToNext()) {

                String day = cursor.getString(
                        cursor.getColumnIndexOrThrow("day")
                );

                // Hanya mengambil jadwal sesuai hari sekarang
                if (day != null &&
                        normalizeDay(day).equals(normalizeDay(today))) {

                    totalToday++;

                    String course = cursor.getString(
                            cursor.getColumnIndexOrThrow("course_name")
                    );

                    String start = cursor.getString(
                            cursor.getColumnIndexOrThrow("start_time")
                    );

                    String end = cursor.getString(
                            cursor.getColumnIndexOrThrow("end_time")
                    );

                    String lecturer = cursor.getString(
                            cursor.getColumnIndexOrThrow("lecturer")
                    );

                    String room = cursor.getString(
                            cursor.getColumnIndexOrThrow("room")
                    );

                    createScheduleCard(
                            course,
                            start,
                            end,
                            lecturer,
                            room
                    );
                }
            }

        } finally {
            cursor.close();
        }

        // Perbarui jumlah mata kuliah hari ini
        txtScheduleCount.setText(String.valueOf(totalToday));

        // Jika tidak ada jadwal
        if (totalToday == 0) {

            txtEmptySchedule.setVisibility(View.VISIBLE);

            txtEmptySchedule.setText(
                    "Tidak ada jadwal kuliah hari ini.\n" +
                            "Selamat menikmati waktu luang!"
            );

        } else {

            txtEmptySchedule.setVisibility(View.GONE);
        }
    }

    private void createScheduleCard(
            String course,
            String start,
            String end,
            String lecturer,
            String room
    ) {

        // Card jadwal
        LinearLayout card = new LinearLayout(this);

        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 16, 18, 16);

        card.setBackgroundResource(
                R.drawable.bg_dashboard_card
        );

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        cardParams.setMargins(0, 0, 0, 14);

        card.setLayoutParams(cardParams);

        // Nama mata kuliah
        TextView txtCourse = new TextView(this);

        txtCourse.setText(course);
        txtCourse.setTextColor(Color.rgb(23, 43, 77));
        txtCourse.setTextSize(16);
        txtCourse.setTypeface(null, Typeface.BOLD);

        // Waktu kuliah
        TextView txtTime = new TextView(this);

        txtTime.setText(start + " - " + end);
        txtTime.setTextColor(Color.rgb(49, 95, 173));
        txtTime.setTextSize(13);
        txtTime.setPadding(0, 7, 0, 7);

        // Informasi dosen dan ruangan
        TextView txtDetail = new TextView(this);

        txtDetail.setText(
                "Dosen: " + safeText(lecturer) + "\n" +
                        "Ruangan: " + safeText(room)
        );

        txtDetail.setTextColor(Color.rgb(135, 147, 168));
        txtDetail.setTextSize(12);
        txtDetail.setLineSpacing(5, 1);

        card.addView(txtCourse);
        card.addView(txtTime);
        card.addView(txtDetail);

        layoutScheduleHome.addView(card);
    }

    private String normalizeDay(String day) {
        return day.trim().toLowerCase(new Locale("id", "ID"));
    }

    private String capitalize(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }

        return text.substring(0, 1).toUpperCase(
                new Locale("id", "ID")
        ) + text.substring(1);
    }

    private String safeText(String value) {
        if (value == null || value.trim().isEmpty()) {
            return "-";
        }

        return value;
    }
}
