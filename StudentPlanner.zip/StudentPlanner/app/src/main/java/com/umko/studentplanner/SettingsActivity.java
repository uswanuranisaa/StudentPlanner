
package com.umko.studentplanner;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    EditText edtName, edtSemester;
    Button btnSave;
    PrefsManager prefsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefsManager = new PrefsManager(this);

        edtName = findViewById(R.id.edtName);
        edtSemester = findViewById(R.id.edtSemester);
        btnSave = findViewById(R.id.btnSave);

        // Menampilkan data yang sudah tersimpan
        edtName.setText(prefsManager.getName());
        edtSemester.setText(prefsManager.getSemester());

        btnSave.setOnClickListener(v -> {
            String name = edtName.getText().toString().trim();
            String semester = edtSemester.getText().toString().trim();

            if (name.isEmpty() || semester.isEmpty()) {
                Toast.makeText(this,
                        "Nama dan semester wajib diisi",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            int semesterNumber;
            try {
                semesterNumber = Integer.parseInt(semester);
            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Semester harus berupa angka",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (semesterNumber < 1 || semesterNumber > 14) {
                Toast.makeText(this,
                        "Semester harus antara 1 sampai 14",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            prefsManager.saveProfile(name, semester);

            Toast.makeText(this,
                    "Profil berhasil disimpan",
                    Toast.LENGTH_SHORT).show();

            finish();
        });
    }
}
