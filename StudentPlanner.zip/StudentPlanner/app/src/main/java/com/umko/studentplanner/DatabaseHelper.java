
package com.umko.studentplanner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudentPlanner.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_SCHEDULE = "schedules";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_SCHEDULE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "course_name TEXT NOT NULL, " +
                "day TEXT NOT NULL, " +
                "start_time TEXT NOT NULL, " +
                "end_time TEXT NOT NULL, " +
                "lecturer TEXT, " +
                "room TEXT)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEDULE);
        onCreate(db);
    }

    // Menambahkan jadwal
    public boolean insertSchedule(String course, String day,
                                  String start, String end,
                                  String lecturer, String room) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("course_name", course);
        values.put("day", day);
        values.put("start_time", start);
        values.put("end_time", end);
        values.put("lecturer", lecturer);
        values.put("room", room);

        long result = db.insert(TABLE_SCHEDULE, null, values);

        return result != -1;
    }

    // Mengambil seluruh jadwal
    public Cursor getAllSchedules() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_SCHEDULE +
                        " ORDER BY CASE day " +
                        "WHEN 'Senin' THEN 1 " +
                        "WHEN 'Selasa' THEN 2 " +
                        "WHEN 'Rabu' THEN 3 " +
                        "WHEN 'Kamis' THEN 4 " +
                        "WHEN 'Jumat' THEN 5 " +
                        "WHEN 'Sabtu' THEN 6 " +
                        "WHEN 'Minggu' THEN 7 END, start_time ASC",
                null
        );
    }

    // Menghapus jadwal
    public boolean deleteSchedule(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_SCHEDULE,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }
}
