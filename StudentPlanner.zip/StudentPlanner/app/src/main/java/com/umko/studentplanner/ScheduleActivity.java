
package com.umko.studentplanner;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ScheduleActivity extends AppCompatActivity {

    EditText edtCourse, edtStart, edtEnd, edtLecturer, edtRoom;
    Spinner spinnerDay;
    Button btnAdd;
    LinearLayout layoutScheduleList;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        databaseHelper = new DatabaseHelper(this);

        edtCourse = findViewById(R.id.edtCourse);
        edtStart = findViewById(R.id.edtStart);
        edtEnd = findViewById(R.id.edtEnd);
        edtLecturer = findViewById(R.id.edtLecturer);
        edtRoom = findViewById(R.id.edtRoom);

        spinnerDay = findViewById(R.id.spinnerDay);
        btnAdd = findViewById(R.id.btnAdd);
        layoutScheduleList = findViewById(R.id.layoutScheduleList);

        String[] days = {
                "Senin", "Selasa", "Rabu", "Kamis",
                "Jumat", "Sabtu", "Minggu"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                days
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerDay.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> addSchedule());

        loadSchedules();
    }

    private void addSchedule() {

        String course = edtCourse.getText().toString().trim();
        String day = spinnerDay.getSelectedItem().toString();
        String start = edtStart.getText().toString().trim();
        String end = edtEnd.getText().toString().trim();
        String lecturer = edtLecturer.getText().toString().trim();
        String room = edtRoom.getText().toString().trim();

        if (course.isEmpty() || start.isEmpty() || end.isEmpty()) {
            Toast.makeText(this,
                    "Nama mata kuliah dan jam wajib diisi",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = databaseHelper.insertSchedule(
                course, day, start, end, lecturer, room
        );

        if (success) {
            Toast.makeText(this,
                    "Jadwal berhasil ditambahkan",
                    Toast.LENGTH_SHORT).show();

            edtCourse.setText("");
            edtStart.setText("");
            edtEnd.setText("");
            edtLecturer.setText("");
            edtRoom.setText("");

            loadSchedules();

        } else {
            Toast.makeText(this,
                    "Jadwal gagal disimpan",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void loadSchedules() {

        layoutScheduleList.removeAllViews();

        Cursor cursor = databaseHelper.getAllSchedules();

        if (cursor == null) return;

        if (cursor.getCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("Belum ada jadwal kuliah.");
            empty.setTextColor(0xFF8793A8);
            empty.setTextSize(14);
            empty.setPadding(10, 20, 10, 20);

            layoutScheduleList.addView(empty);
            cursor.close();
            return;
        }

        while (cursor.moveToNext()) {

            int id = cursor.getInt(
                    cursor.getColumnIndexOrThrow("id")
            );

            String course = cursor.getString(
                    cursor.getColumnIndexOrThrow("course_name")
            );

            String day = cursor.getString(
                    cursor.getColumnIndexOrThrow("day")
            );

            String start = cursor.getString(
                    cursor.getColumnIndexOrThrow("start_time")
            );

            String end = cursor.getString(
                    cursor.getColumnIndexOrThrow("end_time")
            );

            String lecturer = cursor.getString(
                    cursor.getColumnIndexOrThrow("lecturer")
            );

            String room = cursor.getString(
                    cursor.getColumnIndexOrThrow("room")
            );

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(22, 18, 22, 18);

            android.graphics.drawable.GradientDrawable background =
                    new android.graphics.drawable.GradientDrawable();

            background.setColor(0xFFFFFFFF);
            background.setCornerRadius(24);
            card.setBackground(background);

            LinearLayout.LayoutParams cardParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            cardParams.setMargins(0, 0, 0, 16);
            card.setLayoutParams(cardParams);

            TextView title = new TextView(this);
            title.setText(course);
            title.setTextColor(0xFF172B4D);
            title.setTextSize(17);
            title.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView details = new TextView(this);
            details.setText(
                    day + " • " + start + " - " + end +
                            "\nDosen: " + (lecturer.isEmpty() ? "-" : lecturer) +
                            "\nRuangan: " + (room.isEmpty() ? "-" : room)
            );

            details.setTextColor(0xFF8793A8);
            details.setTextSize(13);
            details.setPadding(0, 10, 0, 12);

            Button deleteButton = new Button(this);
            deleteButton.setText("Hapus Jadwal");
            deleteButton.setAllCaps(false);

            deleteButton.setOnClickListener(v -> {
                boolean deleted = databaseHelper.deleteSchedule(id);

                if (deleted) {
                    Toast.makeText(this,
                            "Jadwal berhasil dihapus",
                            Toast.LENGTH_SHORT).show();
                    loadSchedules();
                }
            });

            card.addView(title);
            card.addView(details);
            card.addView(deleteButton);

            layoutScheduleList.addView(card);
        }

        cursor.close();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseHelper.close();
    }
}
