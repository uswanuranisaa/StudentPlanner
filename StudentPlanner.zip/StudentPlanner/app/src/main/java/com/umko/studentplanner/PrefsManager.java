
package com.umko.studentplanner;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefsManager {

    private static final String PREF_NAME = "StudentPlannerPrefs";

    private static final String KEY_NAME = "student_name";
    private static final String KEY_SEMESTER = "student_semester";
    private static final String KEY_DARK_MODE = "dark_mode";
    private static final String KEY_NOTIFICATION = "notification";

    private final SharedPreferences preferences;

    public PrefsManager(Context context) {
        preferences = context.getSharedPreferences(
                PREF_NAME,
                Context.MODE_PRIVATE
        );
    }

    // Menyimpan profil mahasiswa
    public void saveProfile(String name, String semester) {
        preferences.edit()
                .putString(KEY_NAME, name)
                .putString(KEY_SEMESTER, semester)
                .apply();
    }

    // Mengambil nama mahasiswa
    public String getName() {
        return preferences.getString(KEY_NAME, "Mahasiswa");
    }

    // Mengambil semester
    public String getSemester() {
        return preferences.getString(KEY_SEMESTER, "6");
    }

    // Menyimpan pengaturan dark mode
    public void setDarkMode(boolean enabled) {
        preferences.edit()
                .putBoolean(KEY_DARK_MODE, enabled)
                .apply();
    }

    public boolean isDarkMode() {
        return preferences.getBoolean(KEY_DARK_MODE, false);
    }

    // Menyimpan pengaturan notifikasi
    public void setNotification(boolean enabled) {
        preferences.edit()
                .putBoolean(KEY_NOTIFICATION, enabled)
                .apply();
    }

    public boolean isNotificationEnabled() {
        return preferences.getBoolean(KEY_NOTIFICATION, true);
    }
}
